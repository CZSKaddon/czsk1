#!/usr/bin/env node

const express        = require('express');
const bodyParser     = require('body-parser');
const { getRouter }  = require('stremio-addon-sdk');
const addonInterface = require('./addon');
const bcrypt         = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const low            = require('lowdb');
const FileSync       = require('lowdb/adapters/FileSync');

// Admin credentials for Basic Auth
const ADMIN_USER = 'czsk';
const ADMIN_PASS = 'IPTVczsk';

const PORT       = 8000;
const MOUNT_PATH = '/:token/:deviceId';

// 1) Init lowdb (users & tokens)
const adapter = new FileSync('db.json');
const db      = low(adapter);
db.defaults({ users: [], tokens: [] }).write();

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Basic Auth middleware for admin
function adminAuth(req, res, next) {
  const auth = req.headers.authorization || '';
  if (!auth.startsWith('Basic ')) {
    res.set('WWW-Authenticate', 'Basic realm="Admin Area"');
    return res.status(401).send('Authentication required.');
  }
  const [user, pass] = Buffer.from(auth.split(' ')[1], 'base64').toString().split(':');
  if (user === ADMIN_USER && pass === ADMIN_PASS) {
    return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="Admin Area"');
  return res.status(401).send('Invalid credentials.');
}

// Helper to compute expiry timestamp
function calcExpiry(days) {
  return Date.now() + days * 24 * 60 * 60 * 1000;
}

// 2) Admin UI: show registration form + user list + actions
app.get('/admin', adminAuth, (req, res) => {
  const users  = db.get('users').value();
  const tokens = db.get('tokens').value();
  res.send(`
    <!DOCTYPE html>
    <html>
      <head><meta charset="utf-8"><title>Admin Dashboard</title></head>
      <body style="font-family:sans-serif;max-width:800px;margin:auto;">
        <h1>Admin Dashboard</h1>

        <h2>Register New User</h2>
        <form method="POST" action="/admin/register">
          <label>Username:<br><input name="username" required></label><br>
          <label>Password:<br><input type="password" name="password" required></label><br>
          <label>Device MAC:<br><input name="deviceMac" placeholder="AA:BB:CC:DD:EE:FF" required></label><br>
          <label>Days Valid:<br><input type="number" name="daysValid" min="1" required></label><br>
          <button type="submit">Create Account</button>
        </form>

        <h2>Existing Users</h2>
        <table border="1" cellpadding="5" cellspacing="0" width="100%">
          <tr><th>Username</th><th>Expires At</th><th>Token</th><th>Device MAC</th><th>Actions</th></tr>
          ${users.map(user => {
            const t = tokens.find(t => t.username === user.username) || {};
            const expDate = new Date(user.expiresAt).toLocaleString();
            return `
              <tr>
                <td>${user.username}</td>
                <td>${expDate}</td>
                <td>${t.token || ''}</td>
                <td>${t.deviceId || ''}</td>
                <td>
                  <form style="display:inline;" method="POST" action="/admin/revoke">
                    <input type="hidden" name="username" value="${user.username}">
                    <button type="submit">Revoke</button>
                  </form>
                  <form style="display:inline;" method="POST" action="/admin/reset">
                    <input type="hidden" name="username" value="${user.username}">
                    <input type="number" name="daysValid" min="1" placeholder="Days">
                    <button type="submit">Reset Expiry</button>
                  </form>
                </td>
              </tr>`;
          }).join('')}
        </table>
      </body>
    </html>
  `);
});

// 3) Admin: handle user registration
app.post('/admin/register', adminAuth, async (req, res) => {
  const { username, password, daysValid, deviceMac } = req.body;
  if (!username || !password || !daysValid || !deviceMac) {
    return res.status(400).send('All fields required');
  }
  if (db.get('users').find({ username }).value()) {
    return res.status(409).send('User already exists');
  }
  const hash = await bcrypt.hash(password, 10);
  db.get('users').push({ username, hash, expiresAt: calcExpiry(Number(daysValid)) }).write();
  const token = uuidv4();
  db.get('tokens').push({ username, token, deviceId: deviceMac }).write();
  res.redirect('/admin');
});

// 4) Admin: revoke user (remove user & token)
app.post('/admin/revoke', adminAuth, (req, res) => {
  const { username } = req.body;
  db.get('users').remove({ username }).write();
  db.get('tokens').remove({ username }).write();
  res.redirect('/admin');
});

// 5) Admin: reset expiry
app.post('/admin/reset', adminAuth, (req, res) => {
  const { username, daysValid } = req.body;
  if (!daysValid) return res.status(400).send('Days valid required');
  const user = db.get('users').find({ username }).value();
  if (user) {
    db.get('users').find({ username }).assign({ expiresAt: calcExpiry(Number(daysValid)) }).write();
  }
  res.redirect('/admin');
});

// 6) Registration endpoint (public)
app.post('/register', async (req, res) => {
  const { username, password, daysValid } = req.body;
  if (!username || !password || !daysValid) {
    return res.status(400).json({ error: 'username, password, daysValid required' });
  }
  if (db.get('users').find({ username }).value()) {
    return res.status(409).json({ error: 'User exists' });
  }
  const hash = await bcrypt.hash(password, 10);
  db.get('users').push({ username, hash, expiresAt: calcExpiry(daysValid) }).write();
  res.json({ message: 'Registered!' });
});

// 7) Login endpoint (public)
app.post('/login', async (req, res) => {
  const { username, password, deviceId } = req.body;
  const user = db.get('users').find({ username }).value();
  if (!user || !(await bcrypt.compare(password, user.hash))) {
    return res.status(401).json({ error: 'Invalid creds' });
  }
  if (Date.now() > user.expiresAt) {
    return res.status(403).json({ error: 'Account expired' });
  }
  const existing = db.get('tokens').find({ username }).value();
  if (existing && existing.deviceId !== deviceId) {
    return res.status(403).json({ error: 'Already on another device' });
  }
  const token = uuidv4();
  db.get('tokens').remove({ username }).write();
  db.get('tokens').push({ username, token, deviceId }).write();
  res.json({ token });
});

// 8) Auth middleware for addon routes ONLY
app.use(MOUNT_PATH, (req, res, next) => {
  const { token, deviceId } = req.params;
  const entry = db.get('tokens').find({ token, deviceId }).value();
  if (!entry) return res.status(401).end('Invalid token/device');
  const user = db.get('users').find({ username: entry.username }).value();
  if (Date.now() > user.expiresAt) return res.status(403).end('Account expired');
  next();
});

// 9) Mount your Stremio addon on that dynamic path
app.use(MOUNT_PATH, getRouter(addonInterface));

// 10) Start Express on port 8000
app.listen(PORT, () => {
  console.log(`🚀 Addon running at http://127.0.0.1:${PORT}${MOUNT_PATH}/manifest.json`);
});
